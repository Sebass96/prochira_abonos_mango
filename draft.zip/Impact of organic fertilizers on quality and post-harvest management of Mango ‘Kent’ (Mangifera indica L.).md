**Impact of organic fertilizers on the quality of mango (*Mangifera indica* L.) var. 'Kent' during physiological maturity and commercial maturity.** 

Henry Morocho-Romero^1,2†^; Ricardo Peña-Castillo^2†^; Arturo Morales-Pizarro^2†.^ Junior Domínguez-Chozo^2^; Sandy Vilchez-Navarro^1,2^, Sebastian Casas-Niño^1^; Gabriela Cárdenas-Huamán^1^; Nery Tirabante-Terrones^1^; Esdwin-Oberti Nuñez-Ticliahuanca^1^; Ana Montañez-Artica^1^; Leslie Velarde-Apaza^1^; Max Ramirez-Rojas^1^; Juancarlos Cruz^1^; Flavio Lozano-Isla^1,3#^.

***​^1^ **Dirección de Supervisión y Monitoreo en las Estaciones Experimentales Agrarias, Instituto Nacional de Innovación Agraria. Lima. Perú.*

*^2^ Universidad Nacional de Piura, Campus Universitario s/n. Urb. Miraflores. Piura, Perú.*

*^3^ Facultad de Ingeniería y Ciencias Agrarias, Universidad Nacional Toribio Rodríguez de Mendoza de Amazonas (UNTRM), Chachapoyas, Peru*

* ^†^ Equal contributing author.*

* ^#^ *Corresponding author: [flavio.lozano@untrm.edu.pe](mailto:flavio.lozano@untrm.edu.pe) 



ORCID IDs:

Henry Morocho-Romero: [0000-0002-1520-2372](https://orcid.org/0000-0002-1520-2372)

Ricardo Peña-Castillo:[0000-0001-9366-4962](https://orcid.org/0000-0001-9366-4962)

Arturo Morales-Pizarro: [0000-0003-3966-6689](https://orcid.org/0000-0003-3966-6689)

Junior Dominguez-Chozo: [0009-0008-4510-5267](https://orcid.org/0009-0008-4510-5267)

Sandy Vilchez-Navarro: [0009-0002-1784-5563](https://orcid.org/0009-0002-1784-5563)

Sebastian Casas-Niño: [0000-0002-6576-8761](https://orcid.org/0000-0002-6576-8761)

Gabriela Cárdenas-Huamán: [0000-0002-8379-5464](https://orcid.org/0000-0002-8379-5464)

Nery Tirabante-Terrones: [0000-0002-0634-1522](https://orcid.org/0000-0002-0634-1522)

Edwin-Oberti Nuñez-Ticliahuanca: [0009-0004-4613-0625](https://orcid.org/0009-0004-4613-0625)

Ana Montañez-Artica: [0000-0003-3580-6621](https://orcid.org/0000-0003-3580-6621)

Leslie Velarde-Apaza: [0000-0001-6031-6355](https://orcid.org/0000-0001-6031-6355)

Max Ramirez-Rojas: [0000-0003-3322-0838 ](https://orcid.org/0000-0003-3322-0838)

Juancarlos Cruz: [0009-0005-8288-2768](https://orcid.org/0009-0005-8288-2768)

Flavio Lozano-Isla: [0000-0002-0714-669X](https://orcid.org/0000-0002-0714-669X)







**Statements and Declarations**

**Author Contributions**

Conceptualization, H.M-R., R.P-C. and A.M-P.; methodology, A.M-P. and J.D-C.; formal analysis, F.L-I. and S.C-N.; investigation, H.M-R.; resources H.M-R.; data curation, F.L-I. and S.C-N.; writing—original draft preparation, H.M-R., S.V-N., G.C-H., N.T-T., E-O.N-T., A.M-A., F.L-I. and S.C-N.; writing—review and editing, F.L-I. and L.V-A.; visualization, F.L-I. and S.C-N.; supervision, J.C. and M.R-R.; funding acquisition, J.C. All authors have read and agreed to the published version of the manuscript.

**Funding**

This work was funded by the company 'Soluciones Orgánicas Loma Fértil,' Piura-Peru, and the National Institute of Agricultural Innovation (INIA), Peru through the investment project N°. 2472190 'El Chira'.

**Data Availability**

The original contributions presented in this study are included in the article and supplementary material. The reproducible data analysis and datasets are available in Supplementary File 2 and can be accessed through the GitHub repository at [https://github.com/Sebass96/prochira\_abonos\_mango](https://github.com/Sebass96/prochira_abonos_mango) 

**Acknowledgments**

The authors want to thank Mr. L. Córdova C. for his support in fieldwork and technical management of the crop. To Eng. C.P. Roque V. for his contribution to the postharvest management of mango

**Conflicts of Interest**

The authors declare no conflict of interest.

# Abstract

Mango (*Mangifera indica* L.) is a fruit tree with high global demand. Its fruit presents morphological, physiological, and biochemical changes during maturation. An adequate nutrient supply during different physiological stages is key to increasing fruit yield and quality. This research was conducted in the Piura region of Peru; eight-year-old mango trees of the 'Kent' variety, were planted at a distance of 7 × 7 m during the 2022–2023 season. A 3 × 3 factorial design with three replications was employed, where the first factor was the application of compost at 0, 5, and 15 t/ha, and the second factor was the application of biol at concentrations of 0%, 5%, and 10%. The results revealed that organic fertilization combined with compost and biol positively affected fruit yield and quality by improving fruit firmness, increasing soluble solids content and decreasing titratable acidity during the physiological and commercial maturity stages. Dry matter increased during physiological maturity and fruit dehydration decreased during commercial maturity. These results demonstrate that the application of organic fertilizers significantly improves mango fruit quality.



**Keywords:** agricultural practices; crop productivity; fruit quality; nutrient management; sustainable farming





# Introduction

The mango (*Mangifera indica* L.) is a tropical fruit tree whose origin dates back to 4000 B.C. in South Asia [(R et al. 2022; Saroj and Prasad 2023)](https://www.zotero.org/google-docs/?0c8sC5). Worldwide, the production of mangoes (M. *indica* L.), guavas (*Psidium guajava*), and mangosteens (*Garcinia mangostana* L.) amounts to 59.15 million metric tons (Mt), with India producing 15.64 Mt, China 3.02 Mt, Indonesia 2.09 Mt, and Thailand 2.07 Mt as the leading producers. On the American continent, production reaches 4.80 Mt, with Mexico and Brazil being the leading producers, contributing 1.78 Mt and 1.21 Mt, respectively [(Food and Agriculture Organization of the United Nations 2022)](https://www.zotero.org/google-docs/?SkrMOj). The high demand for mango globally is attributed to its sensory characteristics and health benefits, making it a tropical treasure among seasonal fruits [(Khadivi et al. 2022; Shivran et al. 2023; Saroj and Prasad 2023)](https://www.zotero.org/google-docs/?QhzXPD).

The mango fruit is a fleshy drupe that undergoes morphological, physiological, and biochemical changes during its physiological and commercial ripening process, which enhances its sensory and organoleptic qualities [(Wang et al. 2019; Thiruchelvam et al. 2020)](https://www.zotero.org/google-docs/?p0uVcK). Physiological maturity, also referred to as harvest maturity, is determined by subjective methods such as visual measurement of skin color, shoulder width, fruit size, or sphericity [(Jha et al. 2006; Benkeblia et al. 2011; Gonzalez-Aguilar et al. 2011; Singh et al. 2013)](https://www.zotero.org/google-docs/?IxPA8W). Similarly, it can be determined through objective methods that involve the destruction of the fruit by physical parameters [(Benkeblia et al. 2011; Gonzalez-Aguilar et al. 2011)](https://www.zotero.org/google-docs/?bnw01F), physiological parameters [(Sudheer and Indira 2007)](https://www.zotero.org/google-docs/?iFPrcE), and biochemical parameters [(Brückner and Wyllie 2008)](https://www.zotero.org/google-docs/?PlDM8N).In the ‘Kent’ variety, the most representative parameters for determining physiological maturity include physical measurements such as weight at 836 g, length at 16.19 cm, volume at 807 cm³ [(Abu et al. 2021)](https://www.zotero.org/google-docs/?8mVZDM), and pulp firmness at 27.92 N [(Muiruri et al. 2022)](https://www.zotero.org/google-docs/?L6QFhw), biochemical measurements such as soluble solids at 8 °Brix [(Jha et al. 2006)](https://www.zotero.org/google-docs/?S0TWS4), and physiological parameters like ethylene production at 0.1123 µl/kg/hr [(Muiruri et al. 2022)](https://www.zotero.org/google-docs/?XkoE6z). On the other hand, commercial maturity is determined by a decrease in chlorophyll, an increase in carotenoids, softening of the cell wall, degradation of polysaccharides, and modification of organic acids, which enhance the sensory perception and flavor of the fruit [(Martínez-González et al. 2017; Martínez et al. 2022; Prasad et al. 2022a; Villarroel and Albornoz 2024)](https://www.zotero.org/google-docs/?xVsuRN). Optimal maturity, along with the mineral nutrition of plants, prevents physiological disorders at the time of harvest, as it avoids nutritional imbalances in the fruits during their post-harvest life [(Maldonado-Celis et al. 2019; Abu et al. 2020)](https://www.zotero.org/google-docs/?ZMVAJL).

A proper nutrient supply during the phenological stages of growth and development ensures optimal fruit yield. However, fruit quality and postharvest management involve addressing aesthetic, physical, chemical, and biological characteristics, as well as the health benefits and environmental impacts associated with production [(Magallanes-López et al. 2020; González-Salas et al. 2021; Estrada-Arellano et al. 2022)](https://www.zotero.org/google-docs/?ifejwC).

Mango fertilization is linked to the application of synthetic NPK fertilizers to achieve high yields. However, synthetic fertilizers and pesticides have caused environmental pollution, decreased soil health, and impacted food security [(Solano 2023; Rivera-Solís et al. 2023)](https://www.zotero.org/google-docs/?Qp1C10). An alternative to mitigate the use of synthetic fertilizers is organic farming, which employs organic composts to achieve native soil fertilization, high-yield crops, high-quality fruits, and reduced environmental pollutants [(Aguiñaga-Bravo et al. 2020; López-Morales et al. 2022)](https://www.zotero.org/google-docs/?0J6IXO). 

The mango plant requires sources of nitrogen, phosphorus, and potassium to achieve optimal vegetative growth, reproductive development, and yield [(Azam et al. 2022; Ma et al. 2023)](https://www.zotero.org/google-docs/?KkZY7p). Organic fertilizers are characterized by lower concentrations of nutrients but a greater number of nutrients because they affect the synthesis of compounds [(Guo et al. 2019)](https://www.zotero.org/google-docs/?Zr2hW7). They can be applied as soil amendments or foliar treatments because they release slowly and improve the yield and quality of mango fruit from trees [(Jurado et al. 2015)](https://www.zotero.org/google-docs/?nZnMcR). Soil amendments improve the soil‒plant system by increasing root hair density, promoting the soil biota, preventing pathogens, and ensuring the gradual mineralization of nutrients [(Sánchez-Hernández et al. 2019; Campos Mariscal et al. 2020; Díaz-Chuquizuta et al. 2022)](https://www.zotero.org/google-docs/?wx9MyZ). Foliar fertilizers stimulate morphological and physiological changes in plants via micronutrients, phytohormones, and aromatic substances, which elongate cell tissues and provide repellent action against pests and diseases [(Liu et al. 2015; Chew et al. 2019; Liu et al. 2021)](https://www.zotero.org/google-docs/?eMg0q1). 

The objective of the present study was to evaluate the effects of organic fertilizers, specifically compost, and biol applied at the soil and foliar levels on the quality of mango fruits at physiological and commercial maturity. The study was conducted in Tambogrande district in Peru during the 2022–2023 production season. 

# 

# Materials and methods

## Study area and plant material

The research area was located in the village of Las Mónicas, Tambogrande district, Piura region, with a latitude of 4° 54' 45'' S, longitude of 80° 16' 9'' W, and elevation of 96 m.a.s.l ([Figure  @fig:id.umhwcapm7kiw]:). The climate is characterized by minimum temperatures of 14°C, maximum temperatures of 37.5°C, and monthly accumulated precipitation ranging from 0 mm to 147.7 mm ([Figure  @fig:id.qcsp3ox8lybb]:).

The physical and chemical properties of the soil presented a texture with 68% sand, 16% silt, and 16% clay; a pH of 7.51; an organic matter content of 0.96%; and electrical conductivity of 0.18 dS/m; a nitrogen at 480 mg/kg; a phosphorus content of 25.9 mg/kg; a potassium content of 268 mg/kg; and cation exchange capacity of 10.88 cmol/kg. 

The plant material consisted of eight-year-old ‘Kent’ mango trees, planted with a 7 × 7 meter spacing. The study was conducted from September 2022 to February 2023.

![Research area on organic fertilizers and postharvest fruit quality management of mango (*Mangifera indica* L.) var. 'Kent' in Tambogrande, Piura region. Coordinates: 4° 54’ 45’’ S, 80° 16’ 9’’ W.](img_0.jpg){#fig:id.umhwcapm7kiw}

The ‘Kent’ variety was developed in 1932 in Florida, USA, from seeds of the ‘Brooks’ variety. However, it was not until 1938 that the first fruits were produced, and the variety was officially described in 1945 [(Mandal et al. 2023)](https://www.zotero.org/google-docs/?yAdOh0). In Peru, the ‘Kent’ variety of mango predominates over the other varieties due to its slightly oval shape, dark green color with reddish hues at the base, prominent lenticels around the thin skin, juicy flesh with low fiber, and sweet, buttery flavor. These characteristics have led to increased exports and expansion into new international markets such as South Korea, Belgium, and Germany [(Mirza et al. 2021)](https://www.zotero.org/google-docs/?eL6SVD) **.** 

## Organic fertilizers

The organic fertilizers used in this study include compost as commercial product Compost Nutri Suelo 3M. It was produced by Soluciones Orgánicas Loma Fértil® in Las Monicas-CP7, Piura, Peru. The formulation presents native efficient microorganisms isolated from Tambogrande. The bio was prepared artisanally following the methodology proposed by [Chanduví-García et al. (2023)](https://www.zotero.org/google-docs/?yWNIHW) with modifications. A 200-liter capacity cylinder was used, into which a 25 kg sack of Compost Nutri Suelo 3M was introduced. In a 60-liter pot of water, 12 kg of leaves from native plants such as Altamisa (*Ambrosia peruviana*), Higuerilla (*Ricinus communis*), and Neem (*Azadirachta indica*), which were cut into 2×2 cm squares, was introduced, along with 4 kg of garlic (*Allium sativum*), 4 kg of onion (*Allium cepa*), 3 kg of chili (*Capsicum annuum*), and 20 liters of water. These ingredients were boiled for 8 hours, during which 30 liters of water were added. The boiled ingredients were subsequently placed into a 200-liter cylinder. To this end, 5 liters of fermented maize beverage "chicha de jora", 4 kg of cane molasses, and 4 liters of efficient microorganisms were added, and the cylinder was filled with water to reach its full capacity. The container was then sealed tightly and left for 20 days. 

The physicochemical analysis and nutritional composition of Compost Nutri Suelo 3M and homemade biol were conducted at the Water, Soil, Plants, and Fertilizers Laboratory of the Faculty of Agronomy at the National Agrarian University La Molina, Lima, Peru ([Table 1](?tab=t.0#bookmark=id.uscdin6sqnhr)).






| **Organic fertilizers** | **N (ppm)**             | **P (ppm)**             | **K (ppm)**             | **Ca (ppm)**            | **Mg (ppm)**            | **Na (ppm)**            | **M.O %**               | **pH**                  | **CE dS/m**              |
|-------------------------|-------------------------|-------------------------|-------------------------|-------------------------|-------------------------|-------------------------|-------------------------|-------------------------|--------------------------|
| Compost                 | 20900                   | 20100                   | 25600                   | 44500                   | 28000                   | 2100                    | 28.5                    | 7                       | 31.7                     |
| Biol (p/v)              | 1143.2                  | 181.4                   | 1975                    | 440                     | 145                     | 248                     | 2.14                    | 3.1                     | 10.54                    |




: Chemical analysis and nutritional composition of organic fertilizers, Compost Nutri Suelo 3M, and biol used to evaluate the quality and postharvest characteristics of mango (*Mangifera indica* L.) var. ‘Kent’ in Tambogrande, Piura. {#tbl:id.uscdin6sqnhr}

## 

## Experimental treatments

The organic fertilization treatments used in this study included a control with conventional application (0–0) commonly used by farmers: 150 kg/ha N, 80 kg/ha P₂O₅, 200 kg/ha K₂O, 25 kg/ha  MgO, and 40 kg/ha Ca. Compost was incorporated at different rates, 5 t/ha (5–0) and 15 t/ha (15–0). Biol was applied at two concentrations, 5% (0–5) and 10% (0–10), as well as combinations of compost and biol. These combinations included compost at 5 t/ha with 5% biol (5–5), compost at 5 t/ha with 10% biol (5–10), compost at 15 t/ha with 5% biol (15–5), and compost at 15 t/ha with 10% biol (15–10).

The fertilization application was carried out in a single instance during the fruit formation stage, corresponding to the second fruit drop category BBCH: 73 [(Meier 2018)](https://www.zotero.org/google-docs/?vNqG2N). This involved incorporating the compost into the arable layer around the projected canopy of the tree. In contrast, the biol applications were performed foliar at three intervals: the first coincided with the compost application, the second fifteen days after the first application, and the third coincided twenty days after the second application.

## **Study Variables**

The variables were evaluated during the 2022-2023 growing season. The analysis focused on mango fruits of the ‘Kent’ variety at two stages, physiological maturity BBCH: 87 (harvest maturity) and commercial maturity BBCH: 88 (consumption maturity).

To determine the physiological maturity of mango fruit var. ‘Kent’ for harvesting, visual assessments were conducted on shoulder width, skin color, indentations, and fruit sphericity [(Jha et al. 2006; Benkeblia et al. 2011; Singh et al. 2013; Abu et al. 2020)](https://www.zotero.org/google-docs/?5ay27V). Additionally, a minimum of 120 days post-fruit set was referenced [(Abu et al. 2020)](https://www.zotero.org/google-docs/?1RPuqt). This latter technique is widely used by mango producers in the San Lorenzo-Piura valley.

The traits included yield by plant (YP) and fruit quality variables for physiological maturity. At harvest, five fruits per mango tree were collected, with the fruits being marked before the application of the treatments. The percentage of fruit canopy cover at physiological maturity (PFCCPM, %) was analyzed via an image chart that provides percentage values of carotenoids present in the mango skin (Figure S1). Fruit firmness at physiological maturity (FFPM, kg/cm²) was determined with the aid of a Bosch penetrometer (model FT 327), for which the force (kg) necessary for a piston with a diameter of 11 mm (1cm^2^) to pierce the fruit pulp was calculated [(Baloch and Bibi 2012)](https://www.zotero.org/google-docs/?HJJ9Ko). The internal fruit color at physiological maturity (IFCPM) was analyzed via an image chart generated in our study with representative color codes (Figure S2). The soluble solids content of the fruit at physiological maturity (SSCFPM, ºBrix), fruit pH at physiological maturity (FpHPM), titratable acidity of the fruit at physiological maturity (TAFPM, %), and fruit dry matter percentage at physiological maturity (FDMPPM, %) were analyzed via methods 932.12, 981.12, 942.15, and 963.15 as described in the [Association of Official Analytical Chemists (AOAC, 2005)](https://www.zotero.org/google-docs/?qh4EcI). The fruit physiological maturity index (FPMI) was calculated by dividing the SSCFPM by the TAFPM.

Fifteen mango fruits were sampled from each treatment for the analysis of traits at commercial maturity. The fruits were selected at physiological maturity during harvest and subjected to a commercial ripening process according to the methods [Zamora-Cienfuegos et al. (2022)](https://www.zotero.org/google-docs/?WDYDBk) with minor modifications. The process involves treating mango fruits without refrigeration or ethylene doses. The mangoes were initially stored in a refrigerator at 13±1 ºC for 2 days. Subsequently, the fruits are transferred to a closed room for 12 hours, where the ambient temperature rises to above 26±2 ºC. After this period, the room is opened. The carbon dioxide (CO₂) released by the fruits was expelled via a fan for 12 hours. This procedure was repeated for five days, during which the mango fruits reached commercial maturity. The percentage of fruit dehydration at commercial maturity  (FDPCM, %) was determined by comparing the weights before and after the commercial ripening process. The fruit firmness at commercial maturity (FFCM, kg/cm²) was determined with the aid of a Bosch penetrometer (model FT 327), for which the force (kg) necessary for a piston with a diameter of 11 mm (1cm^2^) to pierce the fruit pulp was calculated [(Baloch and Bibi 2012)](https://www.zotero.org/google-docs/?bP0083). The internal fruit color at commercial maturity (IFCCM) was analyzed via a color-coded image chart (Figure S2). The soluble solids content of the fruit at commercial maturity (SSCFCM, °Brix), fruit pH at commercial maturity (FpHCM), and titratable acidity of the fruit at commercial maturity  (TAFCM, %) were measured via methods 932.12, 981.12, and 942.15 from the [Association of Official Analytical Chemists (AOAC, 2005)](https://www.zotero.org/google-docs/?FM4M7l). The commercial maturity index of the fruit (FCMI) was calculated by dividing the SSCFCM by the percentage of TAFCM.

## Statistical analysis

The experiment was carried out via a 3 × 3 factorial design with three replications. The first factor was the application of compost at concentrations of 0, 5, and 15 t/ha, and the second factor was the application of biol at concentrations of 0%, 5%, and 10%. The experimental unit consisted of five mango trees. Three plants were randomly selected for the evaluations YP, PFCCPM, FFCM, IFCPM, SSCFCM, FpHPM, TAFPM, FDMPPM, FPMI, FDPCM, FFCM, IFCCM, SSCFCM, FpHCM, TAFCM, and FCMI. Five fruits per plant were evaluated for analysis at physiological maturity. Fifteen fruits per treatment were selected for analysis of fruits at commercial maturity. An analysis of variance (ANOVA) was conducted to determine if there were differences among the treatment applications. The mean comparison test used was Tukey's test implemented in the R package *emmeans* [(Searle et al. 1980)](https://www.zotero.org/google-docs/?RqdqHS). The 16 variables under study were subjected to multivariate analysis of principal components (PCA) via the *FactoMineR* package [(Francois Husson et al. 2006)](https://www.zotero.org/google-docs/?7uqEPX). The correlation analysis of variables in PCA was conducted via the corrplot package. The data analysis was performed via R statistical software version 4.4.1 (Supplementary File 2, [R Core Team, 2024)](https://www.zotero.org/google-docs/?i9Y5V5).

# Results

## Wheater conditions

To determine the effects of meteorological conditions on mango cultivation during physiological and commercial maturity, the following variables were used: temperature, precipitation, and relative humidity ([Figure  @fig:id.qcsp3ox8lybb]:). These variables determine the presence of pests, diseases, and physiological deficiencies that affect fruit production and quality [(Ullah et al. 2024)](https://www.zotero.org/google-docs/?FLYdsJ).

The lowest temperature values were recorded from September to December 2022, reaching 14.0 °C in October. Moreover, the highest temperature values were observed in January and February 2023, reaching 37.5 °C in January. For precipitation, the highest values were recorded in February 2023, with an accumulation of 147.7 mm, which coincided with the highest relative humidity percentage of 67.91%. On the other hand, the lowest relative humidity value of 57.94% was recorded in January, which coincided with the highest temperature. The temperatures recorded during January and February favored fruit ripening. 

![Weather conditions during the experiment of organic fertilizers in the quality and postharvest management of mango (*Mangifera indica* L.) Var. ‘Kent’, Located in the District of Tambogrande, Piura Región. Source: SENAMHI.](img_1.jpg){#fig:id.qcsp3ox8lybb}

## **Fruit quality traits at physiological maturity**

To evaluate the quality characteristics of the fruit at physiological maturity ([Figure  @fig:kix.jeoh8ws8urib]:), a univariate analysis was conducted at physiological maturity on fruit firmness (FFPM), soluble solids content of the fruit (SSCFPM), titratable acidity of the fruit (TAFPM), and fruit dry matter percentage (FDMPPM). These variables are crucial for determining the physiological maturity of the fruit at harvest and in preventing damage from handling during commercialization or industrial processes [(Kumar et al. 2022; Alebidi et al. 2023)](https://www.zotero.org/google-docs/?uXWLFS).

![Quality traits for 'Kent' mango fruit at physiological maturity. (a) Fruit firmness. (b) Soluble solids content of the fruit. (c) Titratable acidity of the fruit (d) Fruit dry matter percentage. The 0-0 combination represents the synthetic fertilizer application commonly used by the farmer which is equivalent to 150 kg/ha of N, 80 kg/ha of P₂O₅, 200 kg/ha of K₂O, 25 kg/ha of MgO and 40 kg/ha of Ca. Different letters indicate significant differences in Tukey's mean comparison test (p < 0.05).](img_2.jpg){#fig:kix.jeoh8ws8urib}

For FFPM, no significant differences were detected between the interaction of compost and biol applications (p-value = 0.68, [Figure  @fig:kix.jeoh8ws8urib]:a). However, differences were noted in the various doses of compost and biol used. In terms of the application of biol, significant differences were observed across the different doses used at the three compost levels. The 10% biol treated had the highest firmness values, with an average of 12.22 kg/cm^2^. With respect to compost application, the 15 t/ha dose resulted in slightly greater firmness with an average of 11.95 kg/cm^2^. Despite the lack of interaction between the compost and the biol, the application of 15 t/ha + 10% biol resulted in the highest fruit firmness value of 12.96 kg/cm^2^. This value represents a 13.8% increase in firmness compared with that of the control, with firmness of 11.38 kg/cm^2^. 

The interaction between compost and biol significantly affected the SSCFPM (p-value = 0.01, [Figure 3](?tab=t.0#bookmark=kix.jeoh8ws8urib)b). The highest average soluble solids values were achieved with the applications of 15 t/ha compost + 5% biol and 5 t/ha compost + 10% biol, both reaching 9.29 ºBrix. In contrast, the lowest average soluble solids content was observed with the conventional fertilization treatment (0 t/ha compost + 0% biol), which was 8.57 ºBrix. These values represent an 8.4% increase compared with the soluble solids content obtained with the combined application of organic fertilizers at a dose of 15 t/ha compost + 5% biol, compared with the absence of these applications. 

Significant differences were found for TAFPM between the compost and biol interactions (p-value = 0.01, [Figure 3](?tab=t.0#bookmark=kix.jeoh8ws8urib)c). The combined application of organic fertilizers resulted in the lowest average acidity levels, with a dose of 15 t/ha compost + 10% biol resulting in a value of 1.23%. In contrast, the highest acidity values were observed with conventional fertilization (0 t/ha compost + 0% biol), at 1.36%. Notably, applying biol at 10% either individually or in combination with compost resulted in lower acidity values, reaching a maximum of 1.27%.

The FDMPPM did not show significant differences between the interactions of compost and biol application (p-value = 0.61, [Figure 3](?tab=t.0#bookmark=kix.jeoh8ws8urib)d). However, the highest mean value of 20.96% was obtained with the application of 15 t/ha compost + 10% biol. In contrast, the lowest percentage was observed with the conventional fertilization treatment (0 t/ha compost  + 0% biol), at 19.26%, representing an 8% increase in dry matter. Importantly, fruits treated with biol at 10% either individually or in combination with compost exceeded 20.0% dry matter.

To analyze the interaction effects of the variables and organic fertilizer dose at physiological maturity, a principal component analysis (PCA) and a Pearson correlation analysis were conducted with the PCA variable ([Figure  @fig:id.lorxrx2m0tsw]:, Figure S3).

```Unknown element type at this position: UNSUPPORTED```

![Principal Component Analysis (PCA) of quality traits for mango fruits at physiological maturity from compost and biol applications. (a) Physicochemical variables evaluated at physiological maturity for mango fruits. (b) Treatments based on compost and biol used for evaluating agronomic traits. Where: yield per plant (YP), percentage of fruit canopy cover at physiological maturity (PFCCPM, %), fruit firmness at physiological maturity (FFPM, kg/cm^2^), internal fruit color at physiological maturity (IFCPM), soluble solids content of the fruit at physiological maturity (SSCFPM, ºBrix), fruit pH at physiological maturity (FpHPM), titratable acidity of the fruit at physiological maturity (TAFPM, %), fruit dry matter percentage at physiological maturity (FDMPPM, %), fruit physiological maturity index (FPMI). The 0-0 combination represents the synthetic fertilizer application commonly used by the farmer which is equivalent to 150 kg/ha of N, 80 kg/ha of P₂O₅, 200 kg/ha of K₂O, 25 kg/ha of MgO and 40 kg/ha of Ca. Analysis was based on 405 samples (n = 405).](img_3.jpg){#fig:id.lorxrx2m0tsw}



```Unknown element type at this position: UNSUPPORTED```To evaluate the interaction of the traits, a multivariate principal component analysis (PCA) was used ([Figure 4](?tab=t.0#bookmark=id.lorxrx2m0tsw)). The first two components represent 79.29% of the variance at dimension 1 and 10.27% of the variance at dimension 2, resulting in a cumulative variance of 89.56% ([Figure 4](?tab=t.0#bookmark=id.lorxrx2m0tsw)a, Supplementary Figure 3a). For dimension 1, the variables FFPM, FPMI, and FDMPPM contributed the most to this dimension,  with contributions of 13.27%, 13.20%, and 12.62%, respectively, compared with the IFCPM at 4.59% and YP at 7.51% ([Figure 4](?tab=t.0#bookmark=id.lorxrx2m0tsw)a, Supplementary Figure 3b). In dimension 2, the IFCPM had the highest contribution at 71.60%, whereas PFCCPM and YPP had the lowest contributions at 0.18% and 0.88%, respectively ([Figure 4](?tab=t.0#bookmark=id.lorxrx2m0tsw)a, Supplementary Figure 3c). The variables FFPM, FDMPPM, SSCFPM, and TAFPM presented the greatest contribution to the analysis because of  their significance in determining the physiological maturity of the fruit at the time of harvest.

The PCA of the variables illustrates the relationships between the traits. Positive relationships among FFPM, FDMPPM, SSCFPM, TAFPM, IFCPM, FpHPM, FPMI, PFCCPM, and YP were found. In contrast, TAFPM has a negative relationship. There is a strong positive correlation (0.97) between FFPM and a strong negative correlation (-0.93) between TAFPM for dimension 1. For Dimension 2, the variable IFCPM shows a strong positive correlation of 0.81 ([Figure 4](?tab=t.0#bookmark=id.lorxrx2m0tsw)a, Figure S3d).

On the other hand, conventional fertilization (0 t/ha compost + 0% biol) aligns with the direction of the TAFPM vector, indicating that individuals receiving this treatment presented relatively high values of fruit titratable acidity. In the case of the IFCPM, the dose of compost enriched with 15 t/ha +  10% biol had showed the highest value. Similarly, for the variables FFPM and FDMPPM, the application of compost at 15 t/ha + 10% biol had yielded the highest values. For the variables, SSCFPM, FPMI, and FpHPM, the doses of compost at 15 t/ha + 5% biol and compost at 5 t/ha +10% biol had the best results ([Figure 4](?tab=t.0#bookmark=id.lorxrx2m0tsw)b). 

## Characteristics of mango fruit quality at commercial maturity

To evaluate the quality characteristics of the fruit at commercial maturity a univariate analysis was conducted on fruit firmness (FFCM), soluble solids content of the fruit  (SSCFCM), titratable acidity of the fruit (TAFCM), and fruit dehydration percentage (FDPCM). These variables are important for determining the commercial maturity of the fruit in the postharvest handling process [(Saroj and Prasad 2023; Saroj et al. 2023)](https://www.zotero.org/google-docs/?rnMSUZ).

![Quality characteristics for mango fruit of the ‘Kent’ variety at commercial maturity. (a) Fruit firmness at commercial maturity. (b) Soluble solids content of the fruit at commercial maturity. (c) Titratable acidity of the fruit at commercial maturity. (d) Fruit dehydration percentage at commercial maturity. The 0-0 combination represents the synthetic fertilizer application commonly used by the farmer which is equivalent to 150 kg/ha of N, 80 kg/ha of P₂O₅, 200 kg/ha of K₂O, 25 kg/ha of MgO and 40 kg/ha of Ca. Different letters indicate significant differences in Tukey’s multiple comparison tests (p < 0.05).](img_4.jpg){#fig:id.apkbyaf8rnn2}

Significant differences were observed for FFCM between the interactions of compost and biol application (p-value = 0.03). The highest mean value for fruit firmness was obtained with the application of compost at 15 t/ha + 10% biol, with a value of 4.33 kg/cm^2^. In contrast, the lowest mean value for fruit firmness was observed with the application of 0 t/ha compost + 5% biol, at 3.44 kg/cm^2^. This demonstrates a 25.87% increase in fruit firmness ([Figure 5](?tab=t.0#bookmark=id.apkbyaf8rnn2)a).

The SSCFCM did not significantly differ between the interactions of compost and biol (p-value = 0.91, [Figure 5](?tab=t.0#bookmark=id.apkbyaf8rnn2)b). However, differences were observed among the various doses of compost and biol used. The highest mean values of soluble solids were obtained with the application of compost 15 t/ha + 10% biol with 16.12 ºBrix. In contrast, the lowest mean soluble solids content was observed with the application of  5 t/ha compost + 0% biol, at 14.84 ºBrix. These values represent an increase of 8.6% in the soluble solids present in the fruit. 

For TAFCM, significant differences were found between the interactions of compost and biol (p-value < 0.001, [Figure 5](?tab=t.0#bookmark=id.apkbyaf8rnn2)c). With the combined application of organic fertilizers, the lowest mean acidity, 0.47%, was achieved with a dose of compost of 15 t/ha + 10% biol. In contrast, the highest acidity values of 0.62% were observed with conventional fertilization (0 t/ha compost+ 0% biol). Notably, applying compost at 15 t/ha, either alone or in combination with biol, resulted in lower acidity values with values less than 0.51%.

For FDPCM, no significant differences were found in the interaction between compost and biol (p-value = 0.40, [Figure 5](?tab=t.0#bookmark=id.apkbyaf8rnn2)d). However, differences were observed among the various doses of compost and biol used. With respect to the application of biol, significant differences were observed compost doses of 0 t/ha and 10 t/ha. The doses with no biol application (0%) resulted in the greatest degree of fruit dehydration, with an average of 6.58%. With respect to compost application, the 0 t/ha dose resulted in a relatively high percentage of dehydration, with a mean value of 6.57%. Despite the lack of interaction between the compost and the biol, the application of 15 t/ha compost + 10% biol resulted in the lowest dehydration value of 6.16%. This represents an 8.9% decrease in fruit dehydration compared with the 6.76% observed with conventional fertilization (0 t/ha compost + biol 0% biol). 

To analyze the interaction of the traits and treatments with different doses of organic fertilizers a principal component analysis (PCA) and Pearson correlation analysis were conducted in the PCA variables ([Figure  @fig:id.awvbghja6kxt]:, Figure S4).

```Unknown element type at this position: UNSUPPORTED```

![Principal Component Analysis (PCA) of physicochemical variables of mango fruits at commercial maturity with compost and biol applications. (a) Physicochemical traits of fruits at commercial maturity. (b) Treatments based on compost and biol-base were used to evaluate the agronomic traits. Where: fruit dehydration percentage at commercial maturity (FDPCM, %), fruit firmness at commercial maturity (FFCM, kg/cm^2^), internal fruit color at commercial maturity (IFCCM), soluble solids content of the fruit at commercial maturity (SSCFCM, °Brix), fruit pH at commercial maturity (FpHCM), titratable acidity of the fruit at commercial maturity (TAFCM, %), and fruit commercial maturity index (FCMI). The 0-0 combination represents the synthetic fertilizer application commonly used by the farmer which is equivalent to 150 kg/ha of N, 80 kg/ha of P₂O₅, 200 kg/ha of K₂O, 25 kg/ha of MgO and 40 kg/ha of Ca. Analysis based on 135 samples (n = 135).](img_5.jpg){#fig:id.awvbghja6kxt}



```Unknown element type at this position: UNSUPPORTED```To evaluate the interaction of the variables at commercial maturity a multivariate principal component analysis (PCA) method was used ([Figure 6](?tab=t.0#bookmark=id.awvbghja6kxt)). The first two components represent 84.79% of the variance at dimension 1 and 10.35% at dimension 2 representing a cumulative variance of 95.14% ([Figure 6](?tab=t.0#bookmark=id.awvbghja6kxt)a, Figure S4a). For dimension 1, the variables FDPCM and SSCFCM contributed the most to this dimension with values of 16.06% and 16.24%, respectively, compared with the IFCCM with an 8.50% contribution ([Figure 6](?tab=t.0#bookmark=id.awvbghja6kxt)a, Figure S4b). In dimension 2, the IFCCM had the highest contribution at 64.34%, whereas the FDPCM and fruit SSCFCM had the lowest contributions at 1.57% and 0.49%, respectively ([Figure 6](?tab=t.0#bookmark=id.awvbghja6kxt)a, Figure S4c). Importantly, the variables FDPCM, SSCFCM, IFCCM, TAFCM, FpHCM, and FFCM presented high contributions to the analysis because of their importance in determining the commercial maturity of the fruit for sale.

The PCA of the variables shows the relationship between the variables, with a positive correlation among the variables SSCFCM, IFCCM, FpHCM, and FFCM, in contrast with fruit FDPCM and TAFCM, which show a negative correlation ([Figure 6](?tab=t.0#bookmark=id.awvbghja6kxt)a, Figura A.4d). At this point, it is notable that the variable SSCFCM shows a strong positive correlation of 0.98, while the variable FDPCM exhibits a strong negative correlation of -0.98 for dimension 1. Additionally, for dimension 2, the variable IFCCM demonstrates a moderate positive correlation of 0.68 ([Figure 6](?tab=t.0#bookmark=id.awvbghja6kxt)a, Figura A.4d).

Conventional fertilization (0 t/ha compost + 0% biol) and 0 t/ha compost + 5% biol are aligned with the vectors for FDPCM and titratable TAFCM. Therefore, the individuals subjected to these treatments presented higher values for these variables  ([Figure 6](?tab=t.0#bookmark=id.awvbghja6kxt)). In the case of the IFCCM, the conventional fertilization dose (0 t/ha compost + 0% biol) also presented the lowest values. Similarly, for the variables FFCM and SSCFCM, the application of compost at 15 t/ha + 10% and compost at 15 t/ha + 5% resulted in the highest values. With respect to the IFCCM and FpHCM, the compost dose of 15 t/ha + 10% biol had high values for these variables ([Figure 6](?tab=t.0#bookmark=id.awvbghja6kxt)). 



# Discussion

The mango produced in Peru is a highly demanded crop internationally, as more than 60% of the mango production is exported to countries such as the Netherlands, the United States, Spain, and the Republic of Korea [(Ministerio de Desarrollo Agrario y Riego 2023)](https://www.zotero.org/google-docs/?G6g5us). The use of organic fertilizers and organic molecules increases yield and improves the quality of mango fruit [(Ma et al. 2022; García-Santiago et al. 2023)](https://www.zotero.org/google-docs/?pAkl0Y). In the present study, field research was conducted to assess the efficiency of organic fertilizers on eight-year-old 'Kent' mango plants. Various fruit quality parameters were evaluated at both the physiological and commercial maturity stages.

## Organic fertilizers improve mango quality at physiological maturity

In this study, mango quality at physiological maturity was determined by FFPM, SSCFPM, TAFPM and FDMPPM variables. Where, it was found that the application of biol increased FFPM ([Figure  @fig:kix.jeoh8ws8urib]:a) and SSCFPM ([Figure  @fig:kix.jeoh8ws8urib]:d). This could be attributed to the calcium, potassium, and magnesium nutrients present in biol ([Table 1](?tab=t.0#bookmark=id.uscdin6sqnhr)) which are responsible for  the accumulation of homogalacturonans, the binding of pectin networks, and the formation of phospholipids that structure the cell wall and regulate the water permeability of the membrane [(Vásquez – Rojas 2020; Huang et al. 2023; Morales-Meléndez et al. 2024)](https://www.zotero.org/google-docs/?qxbOL4). Additionally, the combined application of compost and biol increased YP and SSCFPM ([Figure  @fig:kix.jeoh8ws8urib]:b) while decreasing TAFPM ([Figure  @fig:kix.jeoh8ws8urib]:c). This could be due to the presence of phosphorus and potassium in compost and biol ([Table 1](?tab=t.0#bookmark=id.uscdin6sqnhr)), which are involved in carbohydrate accumulation in the fruit and the reduction of acids at the vacuolar level [(Irfan et al. 2019; Navarro et al. 2023)](https://www.zotero.org/google-docs/?ljTf7G). Additionally, compost contains humic acids (Table S1), which, according to [Murbach et al. (2020)](https://www.zotero.org/google-docs/?G2PHiw) act as chelators in nutrient absorption. Although both compost and biol contain calcium, potassium, and magnesium ([Table 1](?tab=t.0#bookmark=id.uscdin6sqnhr)), foliar application of biol increased the FFPM value. This suggests that the foliar application method of organic fertilizer can affect FFPM and FDMPPM, which is in agreement with the findings of [Díaz-Chuquizuta et al. (2022)](https://www.zotero.org/google-docs/?OZ8MR2). The correlation between YP and SSCFPM can be attributed to the nutrients present in compost and biol, such as nitrogen, phosphorus, potassium, calcium, and magnesium ([Table 1](?tab=t.0#bookmark=id.uscdin6sqnhr)). These nutrients, when present in adequate proportions, improve fruit quality by preventing internal disorders [(Ma et al. 2022; Ma et al. 2023)](https://www.zotero.org/google-docs/?hw2pri). 

With respect to the timing of the biol applications, our study involved three applications. This allowed for greater potassium availability throughout fruit development, which, according to [Wang et al. (2019)](https://www.zotero.org/google-docs/?uOeKmO), enhances starch accumulation in fruits. Other studies have reported that the fractionation of foliar applications based on potassium and calcium allows for better assimilation of the product. This is because more than 50% of these nutrients are absorbed during fruit maturation. [Osuna-Enciso et al. (2023)](https://www.zotero.org/google-docs/?LhV0ZL) reported that the application of ethephon generates significant differences in fruit firmness, soluble solids, and acidity at harvest [(Sotiropoulos et al. 2021; Jaime-Guerrero et al. 2024)](https://www.zotero.org/google-docs/?pmvOXp).

## Organic fertilizers improve mango quality at commercial maturity.

During the commercial maturity stage, mango shows physicochemical changes reflected in quality variables such as FFCM, SSCFCM, TAFCM, and FDPCM. In the present study, the interaction of compost and biol improved FFCM ([Figure 5](?tab=t.0#bookmark=id.apkbyaf8rnn2)a) and reduced TAFCM ([Figure 5](?tab=t.0#bookmark=id.apkbyaf8rnn2)c). This can be attributed to the calcium absorbed by the fruits during organic fertilization. According to previous studies, calcium regulates enzymatic activity and increases shelf life during the commercial maturity process [(Kumar et al. 2022; Prasad et al. 2024)](https://www.zotero.org/google-docs/?87eMVG). [Prasad et al. (2024)](https://www.zotero.org/google-docs/?S5cy2K) reported that fruits fertilized with organic fertilizers experienced lower FDPCM during the commercial maturity process. The decrease in TAFCM and the increase in SSCFCM can be attributed to the hydrolysis of starch, which is responsible for the increase in sugars and the decrease in organic acids at the vacuolar level [(Prasad et al. 2022b; Prasad et al. 2024)](https://www.zotero.org/google-docs/?8XltO1). In our work, the improvement in FFCM, increase in SSCFCM, and decrease in TAFCM and FDPCM ([Figure 5](?tab=t.0#bookmark=id.apkbyaf8rnn2)a,c,d) can be attributed to high doses of organic fertilizers. These doses likely increase the supply of nutrients that are potentially delivered to the fruit [(Sudha et al. 2012)](https://www.zotero.org/google-docs/?I5COPJ). These findings are supported by those of [Sun et al. (2022)](https://www.zotero.org/google-docs/?f0Q0cW) who demonstrated that fertilizing mango fruit during the maturation period affects the concentrations of soluble solids, vitamin C, carotenoids, and the water content of the fruit.  Additionally, [Abd El-Rahman (2021)](https://www.zotero.org/google-docs/?WKUN7E) reported that applying compost to soil and biofertilizers through foliar spraying improved the physical properties, soluble solids, acidity percentage, and vitamin C concentration of mango fruit. Other studies mention that the content of photosynthates and nutrients in the leaves is correlated with the total sugars of the fruit because of decreases in water supply [(Hueso et al. 2021; Sun et al. 2022)](https://www.zotero.org/google-docs/?J1lhMp). Although the interaction of compost and biol did not significantly differ for FFPM, FDMPPM, SSCFCM, and FDPCM, the best values of fruit yield and quality were achieved with the highest doses of combined compost and biol. Which can be associated with the increased dosage of nutrients, which has been reported to prevent metabolic imbalances and influence fruit development and maturation [(De Bang et al. 2021)](https://www.zotero.org/google-docs/?cMwYRK).

On the other hand, the correlation between PFCCPM, IFCPM (Figure S3) and IFCCM (Figure S4) with compost and biol applications. Studies show that during physiological and commercial maturity the color of mango flesh and skin is regulated by anthocyanins, carotenoids, flavonoids, chlorophylls and betalains [(Kayesh et al. 2013; Muhammad et al. 2022; Naeem et al. 2023)](https://www.zotero.org/google-docs/?izBkpH). It has also been shown that the uptake of nutrients such as nitrogen, phosphorus and potassium allows the accumulation of anthocyanins and carotenoids and the decrease of chlorophyll [(Liang et al. 2020; Muhammad et al. 2023)](https://www.zotero.org/google-docs/?APg3kk). This could explain the correlation between PFCCPM, IFCPM and IFCCM with compost and biol applications (Figure S3, Figure S4). In this sense, the possible mechanism for the color change of mango skin and flesh is due to the supply and availability of nutrients from organic fertilizers. Since they improve the reserves of nitrogen, phosphorus and potassium in the fruit. 

Among the limitations of the present study is the lack of soil analysis at the end of the experiment, which would have been crucial for determining nutrient extraction by the plants. This omission was due to the coincidence of the harvest time with the physico-chemical analysis of the mango fruits, which were conducted in different provinces. Additionally, no foliar analysis was performed before or after organic fertilization, which would have provided valuable information on nutrient concentrations in the leaves and allowed for more precise adjustments to foliar or soil applications. Despite these limitations, the results of this study contribute to the understanding of sustainable agricultural practices, benefiting both producers and the environment. Another challenge for comparison studies is the lack of specification regarding the exact timing of variable evaluations and the standard determination of harvest maturity in Kent mango. Therefore, adopting the BBCH scale to standardize evaluations and facilitate comparisons between studies is suggested.

Research on organic fertilization of mangoes to achieve cumulative effects that better respond to fruit productivity and quality is necessary. Ideally, the efficiency of compost and biol should be evaluated in different geographic regions with varying climatic and edaphic conditions. New equipment is needed to determine both external and internal fruit coloration, which would encode the carotenoid content and more effectively highlight physical changes in fruit fertilized with organic fertilizers during physiological and commercial maturity.

# Conclusions

The present study revealed that mango fruits of the variety ‘Kent’ analyzed at physiological and commercial maturity presented positive effects when organically fertilized. Organic fertilization using compost and biol not only increased yield but also improved fruit quality. Therefore, compost and biol ensure an adequate supply of nutrients during the fruit filling and maturation stages of the mango variety ‘Kent,’ resulting in high-quality fruit at physiological maturity that persists until commercial maturity. These findings are crucial for optimizing the agronomic management of mangoes in regions such as Piura, Peru, and contribute to the knowledge of sustainable agricultural practices, benefiting both producers and the environment.



# References

[Abd El-Rahman A. 2021. Response of mango trees to mineral, bio-organic fertilizers and growth stimulants. J Plant Prod. 12(9):981–986. https://doi.org/10.21608/jpp.2021.202613.](https://www.zotero.org/google-docs/?Xqsy4g)

[Abu M, Olympio NS, Darko JO. 2021. Determination of harvest maturity for mango (*Mangifera indica* L.) fruit by non-destructive criteria. Agric Sci. 12(10):1103–1118. https://doi.org/10.4236/as.2021.1210071.](https://www.zotero.org/google-docs/?Xqsy4g)

[Abu M, Olympio NS, Ofei Darko J. 2020. Appropriate harvest maturity for mango (*Mangifera indica* L.) fruit using age control and fruit growth and development attributes. Hortic Int J. 4(5):213–219. https://doi.org/10.15406/hij.2020.04.00185.](https://www.zotero.org/google-docs/?Xqsy4g)

[Aguiñaga-Bravo A, Medina-Dzul K, Garruña-Hernández R, Latournerie-Moreno L, Ruíz-Sánchez E. 2020. Efecto de abonos orgánicos sobre el rendimiento, valor nutritivo y capacidad antioxidante de tomate verde (*Physalis ixocarpa*). Acta Univ. 30:1–14. https://doi.org/10.15174/au.2020.2475.](https://www.zotero.org/google-docs/?Xqsy4g)

[Alebidi A, Abdel-Sattar M, Mostafa LY, Hamad ASA, Rihan HZ. 2023. Synergistic effects of applying potassium nitrate spray with putrescine on productivity and fruit quality of mango trees cv. Ewais. Agronomy. 13(11):2717. https://doi.org/10.3390/agronomy13112717.](https://www.zotero.org/google-docs/?Xqsy4g)

[Association of Official Analytical Chemists (ed). 2005. Official methods of analysis, 18th edn. Springer International Publishing, Washington, DC, USA,. https://doi.org/10.1007/978-3-319-45776-5\_36.](https://www.zotero.org/google-docs/?Xqsy4g)

[Azam M, Qadri R, Aslam A, Khan MI, Khan AS, Anwar R, Ghani MA, Ejaz S, Hussain Z, Iqbal MA, Chen J. 2022. Effects of different combinations of N, P and K at different time interval on vegetative, reproductive, yield and quality traits of mango (*Mangifera Indica* . L) cv. Dusehri. Braz J Biol. 82:e235612. https://doi.org/10.1590/1519-6984.235612.](https://www.zotero.org/google-docs/?Xqsy4g)

[Baloch MK, Bibi F. 2012. Effect of harvesting and storage conditions on the post harvest quality and shelf life of mango (*Mangifera indica* L.) fruit. South Afr J Bot. 83:109–116. https://doi.org/10.1016/j.sajb.2012.08.001.](https://www.zotero.org/google-docs/?Xqsy4g)

[Benkeblia N, Tennant DPF, Jawandha SK, Gill PS. 2011. Preharvest and harvest factors influencing the postharvest quality of tropical and subtropical fruits, p 112–142e. Postharvest Biology and Technology of Tropical and Subtropical Fruits. Elsevier. https://doi.org/10.1533/9780857093622.112.](https://www.zotero.org/google-docs/?Xqsy4g)

[Brückner B, Wyllie SG. 2008. Fruit and vegetable flavour: recent advances and future prospects. CRC press Woodhead publ, Boca Raton (Fla.) Cambridge.](https://www.zotero.org/google-docs/?Xqsy4g)

[Campos Mariscal JL, Álvarez Sánchez ME, Maldonado Torres R, Vargas Gustavo A. 2020. Aplicación de abonos orgánicos en el rendimiento y desarrollo radicular en el cultivo de aguacate. Rev Mex Cienc Agríc. 11(2):263–274. https://doi.org/10.29312/remexca.v11i2.2301.](https://www.zotero.org/google-docs/?Xqsy4g)

[Chanduví-García R, Sandoval-Panta MA, Peña-Castillo R, Javier-Alva J, Álvarez LA, Quiroz-Calderón MV, Granda-Wong C, Aguilar-Anccota R, Galecio-Julca M, Morales-Pizarro A, Chanduví-García R, Sandoval-Panta MA, Peña-Castillo R, Javier-Alva J, Álvarez LA, Quiroz-Calderón MV, Granda-Wong C, Aguilar-Anccota R, Galecio-Julca M, Morales-Pizarro A. 2023. Biofertilizante y su correlación entre parámetros productivos y de calidad en limón sutil (*Citrus aurantifolia* Swingle ). Terra Latinoam. 41. https://doi.org/10.28940/terra.v41i0.1685.](https://www.zotero.org/google-docs/?Xqsy4g)

[Chew KW, Chia SR, Yen H-W, Nomanbhay S, Ho Y-C, Show PL. 2019. Transformation of biomass waste into sustainable organic fertilizers. Sustainability. 11(8):2266. https://doi.org/10.3390/su11082266.](https://www.zotero.org/google-docs/?Xqsy4g)

[De Bang TC, Husted S, Laursen KH, Persson DP, Schjoerring JK. 2021. The molecular–physiological functions of mineral macronutrients and their consequences for deficiency symptoms in plants. New Phytol. 229(5):2446–2469. https://doi.org/10.1111/nph.17074.](https://www.zotero.org/google-docs/?Xqsy4g)

[Díaz-Chuquizuta P, Hidalgo-Melendez E, Cabrejo-Sánchez C, Valdés-Rodríguez OA. 2022. Respuesta del Maíz (*Zea mays* L.) a la aplicación foliar de abonos orgánicos líquidos. Chil J Agric Anim Sci. 38(2):144–153. https://doi.org/10.29393/CHJAA38-14RMPO40014.](https://www.zotero.org/google-docs/?Xqsy4g)

[Estrada-Arellano E, Murillo-Amador B, Cervantes-Vázquez TJÁ, Gallegos-Robles MÁ, Fortis-Hernández M, Vázquez-Vázquez C. 2022. Fertilización orgánica para mejorar calidad nutraceútica de híbridos de tomate y su efecto en las propiedades químicas del suelo. Rev TERRA Latinoam. 40. https://doi.org/10.28940/terra.v40i0.1613.](https://www.zotero.org/google-docs/?Xqsy4g)

[Food and Agriculture Organization of the United Nations. 2022. Crops and livestok products. FAOSTAT. https://www.fao.org/faostat/en/#data/QCL/visualize. [accessed 21 May 2024].](https://www.zotero.org/google-docs/?Xqsy4g)

[Francois Husson, Josse J, Le S, Mazet J. 2006. FactoMineR: multivariate exploratory data analysis and data mining. 2.11.](https://www.zotero.org/google-docs/?Xqsy4g)

[García-Santiago JC, González-Fuentes JA, Rojas-Duarte A, Hernández-Pérez A, Aureoles-Rodríguez F, Martínez-Mares R. 2023. Los ácidos húmicos reducen la adición de NPK y mejoran la calidad de mango. Ecosistemas Recur Agropecu. 10(1). https://doi.org/10.19136/era.a10n1.3319.](https://www.zotero.org/google-docs/?Xqsy4g)

[Gonzalez-Aguilar GA, Kader AA, Brecht JK, Toivonen PMA. 2011. Fresh-cut tropical and subtropical fruit products, p 381–419e. Postharvest Biology and Technology of Tropical and Subtropical Fruits. Elsevier. https://doi.org/10.1533/9780857093622.381.](https://www.zotero.org/google-docs/?Xqsy4g)

[González-Salas U, Gallegos-Robles MÁ, Preciado-Rangel P, García-Carrillo M, Rodríguez-Hernández MG, García-Hernández JL, Guzmán-Silos TL. 2021. Efecto de fuentes de nutrición orgánicas e inorgánicas mezcladas con biofertilizantes en la producción y calidad de frutos de melón. Rev TERRA Latinoam. 39. https://doi.org/10.28940/terra.v39i0.904.](https://www.zotero.org/google-docs/?Xqsy4g)

[Guo X, Liu H, Wu S. 2019. Humic substances developed during organic waste composting: Formation mechanisms, structural properties, and agronomic functions. Sci Total Environ. 662:501–510. https://doi.org/10.1016/j.scitotenv.2019.01.137.](https://www.zotero.org/google-docs/?Xqsy4g)

[Huang W, Shi Y, Yan H, Wang H, Wu D, Grierson D, Chen K. 2023. The calcium-mediated homogalacturonan pectin complexation in cell walls contributes the firmness increase in loquat fruit during postharvest storage. J Adv Res. 49:47–62. https://doi.org/10.1016/j.jare.2022.09.009.](https://www.zotero.org/google-docs/?Xqsy4g)

[Hueso A, Camacho G, Gómez-del-Campo M. 2021. Spring deficit irrigation promotes significant reduction on vegetative growth, flowering, fruit growth and production in hedgerow olive orchards (cv. Arbequina). Agric Water Manag. 248:106695. https://doi.org/10.1016/j.agwat.2020.106695.](https://www.zotero.org/google-docs/?Xqsy4g)

[Irfan M, Abbas M, Shah J, Depar N, Si̇al NA. 2019. Interactive effect of phosphorus and boron on plant growth, nutrient accumulation and grain yield of wheat grown on calcareous soil. Eurasian J Soil Sci. https://doi.org/10.18393/EJSS.484654.](https://www.zotero.org/google-docs/?Xqsy4g)

[Jaime-Guerrero M, Álvarez-Herrera JG, Fischer G. 2024. Effect of calcium on fruit quality: A review. Agron Colomb. 42(1):e112026. https://doi.org/10.15446/agron.colomb.v42n1.112026.](https://www.zotero.org/google-docs/?Xqsy4g)

[Jha SN, Kingsly ARP, Chopra S. 2006. Physical and mechanical properties of mango during growth and storage for determination of maturity. J Food Eng. 72(1):73–76. https://doi.org/10.1016/j.jfoodeng.2004.11.020.](https://www.zotero.org/google-docs/?Xqsy4g)

[Jurado MM, Suárez-Estrella F, López MJ, Vargas-García MC, López-González JA, Moreno J. 2015. Enhanced turnover of organic matter fractions by microbial stimulation during lignocellulosic waste composting. Bioresour Technol. 186:15–24. https://doi.org/10.1016/j.biortech.2015.03.059.](https://www.zotero.org/google-docs/?Xqsy4g)

[Kayesh E, Shangguan L, Korir NK, Sun X, Bilkish N, Zhang Y, Han J, Song C, Cheng Z-M, Fang J. 2013. Fruit skin color and the role of anthocyanin. Acta Physiol Plant. 35(10):2879–2890. https://doi.org/10.1007/s11738-013-1332-8.](https://www.zotero.org/google-docs/?Xqsy4g)

[Khadivi A, Mirheidari F, Saeidifar A, Moradi Y. 2022. Identification of the promising mango (*Mangifera indica* L.) genotypes based on morphological and pomological characters. Food Sci Nutr. 10(11):3638–3650. https://doi.org/10.1002/fsn3.2961.](https://www.zotero.org/google-docs/?Xqsy4g)

[Kumar S, Kaushik RA, Jain D, Saini VP, Babu SR, Choudhary R, Ercisli S. 2022. Genetic diversity among local mango (*Mangifera indica*  L.) germplasm using morphological, biochemical and chloroplast DNA barcodes analyses. Mol Biol Rep. 49(5):3491–3501. https://doi.org/10.1007/s11033-022-07186-7.](https://www.zotero.org/google-docs/?Xqsy4g)

[Liang M, Su X, Yang Z, Deng H, Yang Z, Liang R, Huang J. 2020. Carotenoid composition and expression of carotenogenic genes in the peel and pulp of commercial mango fruit cultivars. Sci Hortic. 263:109072. https://doi.org/10.1016/j.scienta.2019.109072.](https://www.zotero.org/google-docs/?Xqsy4g)

[Liu H, Li J, Li X, Zheng Y, Feng S, Jiang G. 2015. Mitigating greenhouse gas emissions through replacement of chemical fertilizer with organic manure in a temperate farmland. Sci Bull. 60(6):598–606. https://doi.org/10.1007/s11434-014-0679-6.](https://www.zotero.org/google-docs/?Xqsy4g)

[Liu J, Shu A, Song W, Shi W, Li M, Zhang W, Li Z, Liu G, Yuan F, Zhang S, Liu Z, Gao Z. 2021. Long-term organic fertilizer substitution increases rice yield by improving soil properties and regulating soil bacteria. Geoderma. 404:115287. https://doi.org/10.1016/j.geoderma.2021.115287.](https://www.zotero.org/google-docs/?Xqsy4g)

[López-Morales ML, Leos-Escobedo L, Alfaro-Hernández L, Morales-Morales AE. 2022. Impacto de abonos orgánicos asociados con micorrizas sobre rendimiento y calidad nutraceútica del pepino. Rev Mex Cienc Agríc. 13(5):785–798. https://doi.org/10.29312/remexca.v13i5.2868.](https://www.zotero.org/google-docs/?Xqsy4g)

[Ma X, Liu B, Zhang Y, Su M, Zheng B, Wang S, Wu H. 2023. Unraveling correlations between calcium deficiency and spongy tissue in mango fruit flesh. Sci Hortic. 309:111694. https://doi.org/10.1016/j.scienta.2022.111694.](https://www.zotero.org/google-docs/?Xqsy4g)

[Ma X, Wang J, Su M, Liu B, Du B, Zhang Y, He L, Wang S, Wu H. 2022. The link between mineral elements variation and internal flesh breakdown of ‘Keitt’ mango in a steep slope mountain area, Southwest China. Horticulturae. 8(6):533. https://doi.org/10.3390/horticulturae8060533.](https://www.zotero.org/google-docs/?Xqsy4g)

[Magallanes-López AM, Martínez-Damián MT, Jaime Sahagún-Castellanos, Pérez-Flores LJ, Marín-Montes IM, Rodríguez-Pérez JE. 2020. Calidad poscosecha de 40 poblaciones de tomate (*Solanum lycopersicum* L.) nativas de México. Agrociencia. 54(6):779–796. https://doi.org/10.47163/agrociencia.v54i6.2184.](https://www.zotero.org/google-docs/?Xqsy4g)

[Maldonado-Celis ME, Yahia EM, Bedoya R, Landázuri P, Loango N, Aguillón J, Restrepo B, Guerrero Ospina JC. 2019. Chemical composition of mango (*Mangifera indica* L.) fruit: nutritional and phytochemical compounds. Front Plant Sci. 10:1073. https://doi.org/10.3389/fpls.2019.01073.](https://www.zotero.org/google-docs/?Xqsy4g)

[Mandal D, Wermund U, Phavaphutanon L, Cronje R (eds). 2023. Tropical and subtropical fruit crops: production, processing, and marketing, First edition. Apple Academic Press, Palm Bay, FL burlington, ON.](https://www.zotero.org/google-docs/?Xqsy4g)

[Martínez E, Abud Archila M, Freile Pelegrín Y, Luján Hidalgo MC, Gutiérrez Miceli FA, Ovando Chacón SL. 2022. Recubrimientos a base de alginato de sodio extraído de *Sargassum fluitans* y nanopartículas de plata para prolongar la vida de anaquel de papaya (*Carica papaya* L.). Biotecnia. 24(3):159–168. https://doi.org/10.18633/biotecnia.v24i3.1739.](https://www.zotero.org/google-docs/?Xqsy4g)

[Martínez-González ME, Balois Morales R, Alia-Tejacal I, Cortes-Cruz MA, Palomino-Hermosillo YA, López-Gúzman GG. 2017. Postcosecha de frutos: maduración y cambios bioquímicos. Rev Mex Cienc Agríc. (19):4075–4087. https://doi.org/10.29312/remexca.v0i19.674.](https://www.zotero.org/google-docs/?Xqsy4g)

[Meier U. 2018. Etapas de desarrollo de las plantas monocotiledóneas y dicotiledóneas: BBCH Monografia. https://doi.org/10.5073/20180906-075743.](https://www.zotero.org/google-docs/?Xqsy4g)

[Ministerio de Desarrollo Agrario y Riego. 2023. Estadística Agropecuaria. Sist. Integrado Estad. Agrar. https://siea.midagri.gob.pe/portal/siea\_bi/index.html. [accessed 21 May 2024].](https://www.zotero.org/google-docs/?Xqsy4g)

[Mirza B, Croley CR, Ahmad M, Pumarol J, Das N, Sethi G, Bishayee A. 2021. Mango (*Mangifera indica* L.): a magnificent plant with cancer preventive and anticancer therapeutic potential. Crit Rev Food Sci Nutr. 61(13):2125–2151. https://doi.org/10.1080/10408398.2020.1771678.](https://www.zotero.org/google-docs/?Xqsy4g)

[Morales-Meléndez R, Arroyo-Ramírez A, Camposeco-Montejo N, Méndez-López A, López-Pérez MC. 2024. *Ascophyllum nodosum*  y nitrato de calcio como bioestimulantes en el desarrollo y rendimiento de cultivo de tomate. Cienc Lat Rev Científica Multidiscip. 8(1):1574–1589. https://doi.org/10.37811/cl\_rcm.v8i1.9553.](https://www.zotero.org/google-docs/?Xqsy4g)

[Muhammad N, Luo Z, Yang M, Li X, Liu Z, Liu M. 2022. The joint role of the late anthocyanin biosynthetic UFGT-encoding genes in the flowers and fruits coloration of horticultural plants. Sci Hortic. 301:111110. https://doi.org/10.1016/j.scienta.2022.111110.](https://www.zotero.org/google-docs/?Xqsy4g)

[Muhammad N, Luo Z, Yang M, Liu Z, Liu M. 2023. The underlying molecular mechanisms of external factors influencing fruit coloration in fruit trees. Sci Hortic. 309:111615. https://doi.org/10.1016/j.scienta.2022.111615.](https://www.zotero.org/google-docs/?Xqsy4g)

[Muiruri J, Ambuko J, Nyankanga R, Owino W. 2022. Maturity indices of specific mango varieties produced at medium altitude agro-ecological zone in Kenya. Afr J Food Agric Nutr Dev. 22(111):20752–20773. https://doi.org/10.18697/ajfand.111.22025.](https://www.zotero.org/google-docs/?Xqsy4g)

[Murbach TS, Glávits R, Endres JR, Clewell AE, Hirka G, Vértesi A, Béres E, Pasics Szakonyiné I. 2020. A toxicological evaluation of a fulvic and humic acids preparation. Toxicol Rep. 7:1242–1254. https://doi.org/10.1016/j.toxrep.2020.08.030.](https://www.zotero.org/google-docs/?Xqsy4g)

[Naeem M, Zhao W, Ahmad N, Zhao L. 2023. Beyond green and red: unlocking the genetic orchestration of tomato fruit color and pigmentation. Funct Integr Genomics. 23(3):243. https://doi.org/10.1007/s10142-023-01162-5.](https://www.zotero.org/google-docs/?Xqsy4g)

[Navarro CFA, Balois-Morales R, Zurita JOJ, Jiménez VAO, Ramírez IFP, Varela GB, Rosales PUB. 2023. Frutos de mango partenocárpicos y estenospermocárpicos: factores causantes. Rev Bio Cienc. 10. https://doi.org/10.15741/revbio.10.e1480.](https://www.zotero.org/google-docs/?Xqsy4g)

[Osuna-Enciso T, Pérez-Barraza MH, Martínez-Alvarado CO, Hernández-Verdugo S, Osuna-Rodríguez JM, San Martín-Matheis H. 2023. Retraso de floración y calidad del fruto de mango Kent en el sur de Sinaloa, México. Rev Fitotec Mex. 46(4):389. https://doi.org/10.35196/rfm.2023.4.389.](https://www.zotero.org/google-docs/?Xqsy4g)

[Prasad K, Saroj N, Singh SK, Pradhan J, Prasad SS, Kumar S, Maurya S, Kumar A, Srivastava RK, Tiwari RK, Lal MK, Vijayan B, Kumar A, Samal I, Shah U, Kumar R. 2024. Postharvest quality and ripening behaviour of un-explored genotypes of Himalayan plain mango diversity. Heliyon. 10(12):e33247. https://doi.org/10.1016/j.heliyon.2024.e33247.](https://www.zotero.org/google-docs/?Xqsy4g)

[Prasad K, Sharma RR, Asrey R, Sethi S, Srivastav M, Singh D, Arora A. 2022a. Hydrocolloid edible coatings extend shelf life, reduce postharvest decay, and maintain keeping quality of mango fruits (*Mangifera indica* L.) under ambient storage. J Food Biochem. 46(12). https://doi.org/10.1111/jfbc.14481.](https://www.zotero.org/google-docs/?Xqsy4g)

[Prasad K, Singh G, Singh SK, Pradhan J, Kumar U, Singh H. 2022b. Plant extract and essential oil coating prolongs shelf life and maintains keeping quality of papaya fruit during storage. J Food Process Preserv. 46(11). https://doi.org/10.1111/jfpp.17015.](https://www.zotero.org/google-docs/?Xqsy4g)

[R Core Team. 2024. R: a language and environment for statistical computing. R Found Stat Comput Vienna Austria.](https://www.zotero.org/google-docs/?Xqsy4g)

[R M, Singh SK, Srivastav M, Prakash J, Saha S, Pradhan S. 2022. Physico-chemical characterization and biochemical profiling of mango genotypes during different fruit development stages. South Afr J Bot. 149:476–486. https://doi.org/10.1016/j.sajb.2022.06.023.](https://www.zotero.org/google-docs/?Xqsy4g)

[Rivera-Solís LL, Benavides-Mendoza A, Robledo-Olivo A, González-Morales S. 2023. La salud del suelo y el uso de bioestimulantes. Rev Agrar. 20(3):5–10. https://doi.org/10.59741/agraria.v20i3.46.](https://www.zotero.org/google-docs/?Xqsy4g)

[Sánchez-Hernández R, Vásquez-Montiel L, Valdés-Velarde E, Mendoza-Palacios JDD, López-Noverola U, Escamilla-Prado E. 2019. Cambios edáficos provocados por el uso de abonos de origen natural en una región cafetalera de Veracruz, México. Rev TERRA Latinoam. 37(4):351. https://doi.org/10.28940/terra.v37i4.515.](https://www.zotero.org/google-docs/?Xqsy4g)

[Saroj N, Prasad K. 2023. Assessment of Himalayan plain mango genotypes for phytochemicals, biochemical‐nutraceutical characterisation and quality change during storage life. Int J Food Sci Technol. 58(7):3781–3799. https://doi.org/10.1111/ijfs.16480.](https://www.zotero.org/google-docs/?Xqsy4g)

[Saroj N, Prasad K, Singh SK, Kumar V, Maurya S, Maurya P, Tiwari RK, Lal MK, Kumar R. 2023. Characterization of bioactive and fruit quality compounds of promising mango genotypes grown in Himalayan plain region. PeerJ. 11:e15867. https://doi.org/10.7717/peerj.15867.](https://www.zotero.org/google-docs/?Xqsy4g)

[Searle SR, Speed FM, Milliken GA. 1980. Population marginal means in the linear model: an alternative to least squares means. Am Stat. 34(4):216–221. https://doi.org/10.1080/00031305.1980.10483031.](https://www.zotero.org/google-docs/?Xqsy4g)

[Shivran M, Sharma N, Dubey AK, Singh SK, Sharma N, Muthusamy V, Jain M, Singh BP, Singh N, Kumar N, Singh N, Sethi S, Sharma RM. 2023. Scion/rootstock interaction studies for quality traits in mango (*Mangifera indica* L.) varieties. Agronomy. 13(1):204. https://doi.org/10.3390/agronomy13010204.](https://www.zotero.org/google-docs/?Xqsy4g)

[Singh Z, Singh RK, Sane VA, Nath P. 2013. Mango - postharvest biology and biotechnology. Crit Rev Plant Sci. 32(4):217–236. https://doi.org/10.1080/07352689.2012.743399.](https://www.zotero.org/google-docs/?Xqsy4g)

[Solano AB. 2023. Efecto de fuentes fertilizantes nitrogenadas, diferencias en emisiones de CO2, fertilidad del suelo, crecimiento y productividad en el cultivo de “culantro coyote” (*Eryngium foetidum* L.), en Turrialba, Costa Rica. Rev Environ Technol. 4(1):67–86. https://doi.org/10.56205/ret.4-1.4.](https://www.zotero.org/google-docs/?Xqsy4g)

[Sotiropoulos T, Voulgarakis A, Karaiskos D, Chatzistathis T, Manthos I, Dichala O, Mpountla A. 2021. Foliar calcium fertilizers impact on several fruit quality characteristics and leaf and fruit nutritional status of the ‘hayward’ kiwifruit cultivar. Agronomy. 11(2):235. https://doi.org/10.3390/agronomy11020235.](https://www.zotero.org/google-docs/?Xqsy4g)

[Sudha R, Balamohan TN, Soorianathasundaram K. 2012. Effect of Foliar Spray of Nitrogenous Chemicals on Flowering, Fruit Set and Yield in Mango (*Mangifera indica* L.) Cv. Alphonso. J Hortic Sci. 7(2):190–193. https://doi.org/10.24154/jhs.v7i2.373.](https://www.zotero.org/google-docs/?Xqsy4g)

[Sudheer KP, Indira V. 2007. Post harvest technology of horticultural crops. New India Publishing Agency, Pitam Pura, New Delhi.](https://www.zotero.org/google-docs/?Xqsy4g)

[Sun G, Hu T, Liu X, Peng Y, Leng X, Li Y, Yang Q. 2022. Optimizing irrigation and fertilization at various growth stages to improve mango yield, fruit quality and water-fertilizer use efficiency in xerothermic regions. Agric Water Manag. 260:107296. https://doi.org/10.1016/j.agwat.2021.107296.](https://www.zotero.org/google-docs/?Xqsy4g)

[Thiruchelvam T, Landahl S, Terry LA. 2020. Temporal variation of volatile compounds from Sri Lankan mango (*Mangifera indica* L.) fruit during ripening. J Agric Food Res. 2:100053. https://doi.org/10.1016/j.jafr.2020.100053.](https://www.zotero.org/google-docs/?Xqsy4g)

[Ullah MA, Kiloes AM, Aziz AA, Joyce DC. 2024. Impact of factors contributing to internal disorders of mango (*Mangifera indica* L.) fruit—A systematic literature review. Sci Hortic. 331:113150. https://doi.org/10.1016/j.scienta.2024.113150.](https://www.zotero.org/google-docs/?Xqsy4g)

[Vásquez – Rojas E. 2020. Las aplicaciones foliares de calcio-boro y su efecto en calidad interna e incidencia del rajado de frutos de aguaymanto. Rev Investig Agrar. 2(2):37–48. https://doi.org/10.47840/ReInA.2.2.842.](https://www.zotero.org/google-docs/?Xqsy4g)

[Villarroel C, Albornoz K. 2024. Fisiología de la maduración y manejo en postcosecha de frutilla chilena (*Fragaria chiloensis*). Chil J Agric Anim Sci. 40(3):198–212. https://doi.org/10.29393/CHJAAS40-19FMCK20019.](https://www.zotero.org/google-docs/?Xqsy4g)

[Wang R, Tavano EC da R, Lammers M, Martinelli AP, Angenent GC, de Maagd RA. 2019. Re-evaluation of transcription factor function in tomato fruit development and ripening with CRISPR/Cas9-mutagenesis. Sci Rep. 9(1):1696. https://doi.org/10.1038/s41598-018-38170-6.](https://www.zotero.org/google-docs/?Xqsy4g)

[Zamora-Cienfuegos E, S.-García H, Montes-de Oca MM, Tovar-Gómez B. 2022. Aceleración de la maduración en mango ‘Kent’ refrigerado. Rev Fitotec Mex. 27(4):359. https://doi.org/10.35196/rfm.2004.4.359.](https://www.zotero.org/google-docs/?Xqsy4g)



#| newpage

**Highlights**

* Application of compost and biol increase mango sweetness at physiological maturity.
* Organic fertilizers improve internal flesh color and mango fruit blush percentage.
* Using compost and biol reduce mango dehydration by 0.6% in postharvest handling.
* Organic fertilizers maintain mango firmness at 4.39 kg/cm² at commercial maturity.



#| end

# 

# Supplementary material 

**Figure S1:** Scale for * ***percentage values of carotenoids, referred to as fruit blush, where 0% indicates the absence of carotenoids in the fruit, whereas values of 10%, 20%, 30%, 40%, 50%, 60%, 70%, 80%, 90%, and 100% indicate the presence of carotenoids. These percentages are based on the portion of the mango fruit located between the ventral shoulder and the dorsal shoulder, with 100% referencing the total region located between the aforementioned parts.

![null|null](img_6.png)​







**Figure S2:** Scale for values of the pulp color of ripe fruit when subjected to a longitudinal cut between the poles, where the values correspond to a specific color: 1.0 white and green, 1.5 green, 2.0 green and yellow, 2.5 yellow, 3.0 yellow-orange, 3.5 orange, and 4.0 deep orange.



![null|null](img_7.jpg)​





**Figure S3:** Principal component analysis (PCA) of quality traits for mango fruits at physiological maturity from compost and biol applications. Results of the contributions and correlation of variables in the analysis: (a) Percentage of variance explained by each dimension. (b) Contribution of the studied variables to dimension 1. (c) Contribution of the studied variables to dimension 2. (d) Correlation between the studied variables and the dimensions that contribute most to the explanation of the variance.

![null|null](img_8.jpg)​



```Unknown element type at this position: UNSUPPORTED```**Figure S4:** Principal component analysis (PCA) of the physicochemical traits to correlate with fruits at commercial maturity from compost and biol applications. Results of the contributions and correlation of variables in the analysis: (a) Percentage of variance explained by each dimension. (b) Contribution of the studied variables to dimension 1. (c) Contribution of the studied variables to dimension 2. (d) Correlations between the studied variables and the dimensions that contribute most to the explanation of the variance.

![null|null](img_9.jpg)​

















**Table S1:** Values of the nutrients, substances, and properties of the Nutri Suelo 3M compost provided by Soluciones Orgánicas Loma Fértil, Peru in the product's technical data sheet.


| **Nutrients**                                   | **Values**                                       |
|-------------------------------------------------|--------------------------------------------------|
| Nitrogen N(%)                                   | 2.09                                             |
| Phosphorus P (%)                                | 2.01                                             |
| Potassium K (%)                                 | 2.56                                             |
| Calcium Ca (%)                                  | 4.45                                             |
| Magnesium Mg (%)                                | 2.80                                             |
| Silicon Si (%)                                  | 12.0                                             |
| Sodium Na (%)                                   | 0.21                                             |
| Iron Fe (%)                                     | 9.50                                             |
| Copper Cu (ppm)                                 | 19.0                                             |
| Zinc Zn (ppm)                                   | 77.0                                             |
| Manganese Mn (ppm)                              | 241.0                                            |
| Boron B (ppm)                                   | 50.0                                             |
| **Substances**                                  | **Values**                                       |
| Humic acids (%)                                 | 3.37                                             |
| Fulvic acids (%)                                | 2.79                                             |
| Humin (%)                                       | 22.34                                            |
| Organic matter (%)                              | 28.50                                            |
| **Characteristics**                             | **Values**                                       |
| pH                                              | 7.0                                              |
| Electrical conductivity (EC) (dS/m)             | 3.17                                             |
| Cation exchange capacity (CEC) (meq/100 g soil) | 35.0                                             |
| C/N ratio                                       | 26/1                                             |
















# 



# REVIEWER REPORTS



**Reviewer Comments:**



**Reviewer 1**



The article has made significant improvements, but its format still does not meet the requirements of Scientia Horticulturae journal, such as two blank spaces in the paragraph beginning , the list of the reference, the use of uppercase and lowercase letters, and the presence or absence of numbering.



Dear Reviewer, many thanks for your comments and positive feedback. We will provide a detailed response to each of your comments below. All changes in the manuscript were highlighted in red.



**Main issues are:**



1. **Two blank spaces in the paragraph beginning , the list of the reference, the use of uppercase and lowercase letters, and the presence or absence of numbering.**



Thank you for the suggestion. We have corrected the presence of blank spaces in the initial paragraph and throughout the text. Additionally, the bibliographic references have been modified, correcting the use of uppercase, lowercase, and numbering according to the guidelines of Scientia Horticulturae journal.





















# REVIEWER REPORTS



**Reviewer Comments:**



**Reviewer 2**



In this manuscript, the authors evaluated the effect of organic fertilizers on the quality and postharvest management of mango fruit. The study found that the application of organic fertilizers could improve fruit firmness, soluble solids and dry matter content, and decreased titratable acidity and fruit dehydration during the physiological and commercial maturity stages. The manuscript is well written. There are several areas where the authors could improve the manuscript.



Dear Reviewer, many thanks for your comments and positive feedback. We will provide a detailed response to each of your comments below. All changes in the manuscript were highlighted in red.



**The main issues are:**



1. **How is the physiological ripeness of mangoes determined? Is there a standardized method or data available?**



Thank you for your comment. Physiological maturity in mango can be determined using both non-destructive and destructive methods. Non-destructive methods typically involve visual assessment of fruit characteristics (Rees et al., 2012), while destructive methods focus on physiological evaluations (Yahia, 2011). We have incorporated this information into the Introduction (Lines 77-85). Furthermore, we have clarified the specific methods used in Peru to determine physiological maturity, which were also employed in the present study (Lines 164-167).



Rees, D., Farrell, G., Orchard, J.E., 2012. Crop post-harvest: science and technology : perishables. Wiley-Blackwell, Hoboken.



Yahia, E.M., 2011. Postharvest biology and technology of tropical and subtropical fruits, Woodhead publishing series in food science, technology and nutrition. Woodhead publ, Oxford.



1. **What is the possible mechanism by which the use of organic fertilizers changes the color of mango flesh and skin?**



Thank you for your observation. The color of mango flesh and skin is regulated by plant pigments such as anthocyanins, carotenoids, flavonoids, chlorophylls, and betalains (Kayesh et al., 2013; Muhammad et al., 2022; Naeem et al., 2023). Additionally, studies have shown that nutrients like nitrogen, phosphorus, and potassium stimulate the production of secondary metabolites and promote the accumulation of anthocyanins and carotenoids in the fruit (Muhammad et al., 2023; Liang et al., 2020). Based on this, the proposed mechanism is related to the supply and availability of nitrogen, phosphorus, and potassium from organic fertilizers. This information regarding the potential mechanism regulating the color change in mango flesh and skin has been added to the Discussion (Lines 378-386). Furthermore, we have included a note in the Limitations section about the lack of a standardized method to assess maturity (Lines 393-395).



Kayesh, E., Shangguan, L., Korir, N.K., Sun, X., Bilkish, N., Zhang, Y., Han, J., Song, C., Cheng, Z.-M., Fang, J., 2013. Fruit skin color and the role of anthocyanin. Acta Physiol. Plant. 35, 2879–2890. [https://doi.org/10.1007/s11738-013-1332-8](https://doi.org/10.1007/s11738-013-1332-8)

Liang, M., Su, X., Yang, Zhenfeng, Deng, H., Yang, Zhao, Liang, R., Huang, J., 2020. Carotenoid composition and expression of carotenogenic genes in the peel and pulp of commercial mango fruit cultivars. Sci. Hortic. 263, 109072. [https://doi.org/10.1016/j.scienta.2019.109072](https://doi.org/10.1016/j.scienta.2019.109072)

Muhammad, N., Luo, Z., Yang, M., Li, X., Liu, Z., Liu, M., 2022. The joint role of the late anthocyanin biosynthetic UFGT-encoding genes in the flowers and fruits coloration of horticultural plants. Sci. Hortic. 301, 111110. [https://doi.org/10.1016/j.scienta.2022.111110](https://doi.org/10.1016/j.scienta.2022.111110)

Muhammad, N., Luo, Z., Yang, M., Liu, Z., Liu, M., 2023. The underlying molecular mechanisms of external factors influencing fruit coloration in fruit trees. Sci. Hortic. 309, 111615. [https://doi.org/10.1016/j.scienta.2022.111615](https://doi.org/10.1016/j.scienta.2022.111615)

Naeem, M., Zhao, W., Ahmad, N., Zhao, L., 2023. Beyond green and red: unlocking the genetic orchestration of tomato fruit color and pigmentation. Funct. Integr. Genomics 23, 243. [https://doi.org/10.1007/s10142-023-01162-5](https://doi.org/10.1007/s10142-023-01162-5)





1. **Please verify the submitted materials; I am unable to locate Figures A1 and A2. Additionally, I am unable to access the file using the supplementary link provided: [https://github.com/Sebass96/prochira\_abonos\_mango](https://github.com/Sebass96/prochira_abonos_mango).**



Following your suggestions, the placement of Figures S1 and S2 has been improved, and they are now properly located in the supplementary material. This supplementary material is attached in accordance with the Scientia Horticulturae author guidelines. Additionally, the repository information has been made publicly accessible at [https://github.com/Sebass96/prochira\_abonos\_mango](https://github.com/Sebass96/prochira_abonos_mango).